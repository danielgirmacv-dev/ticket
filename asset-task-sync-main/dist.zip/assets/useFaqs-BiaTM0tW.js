import{c,s as t,t as s,v as r}from"./index-QZweQVdc.js";import{c as i,u as n,b as u}from"./query-D60tqEWE.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=c("KeyRound",[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=c("Wifi",[["path",{d:"M12 20h.01",key:"zekei9"}],["path",{d:"M2 8.82a15 15 0 0 1 20 0",key:"dnpr2z"}],["path",{d:"M5 12.859a10 10 0 0 1 14 0",key:"1x1e6c"}],["path",{d:"M8.5 16.429a5 5 0 0 1 7 0",key:"1bycff"}]]);function f(a){return i({queryKey:["faqs",a],queryFn:async()=>(await t.get("/faqs",{params:a})).data})}function F(){const a=n();return u({mutationFn:async e=>(await t.post("/faqs",e)).data,onSuccess:()=>{a.invalidateQueries({queryKey:["faqs"]}),s.success("FAQ created")},onError:e=>{s.error(r(e,"Failed to create FAQ"))}})}function Q(){const a=n();return u({mutationFn:async({id:e,...o})=>(await t.put(`/faqs/${e}`,o)).data,onSuccess:()=>{a.invalidateQueries({queryKey:["faqs"]}),s.success("FAQ updated")},onError:e=>{s.error(r(e,"Failed to update FAQ"))}})}function h(){const a=n();return u({mutationFn:async e=>{await t.delete(`/faqs/${e}`)},onSuccess:()=>{a.invalidateQueries({queryKey:["faqs"]}),s.success("FAQ deleted")},onError:e=>{s.error(r(e,"Failed to delete FAQ"))}})}export{p as K,q as W,F as a,Q as b,h as c,f as u};
