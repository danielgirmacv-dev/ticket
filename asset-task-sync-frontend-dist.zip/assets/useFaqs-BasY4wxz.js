import{c as r,n as s,o as t,p as n}from"./index-BU_ySnrz.js";import{c as i,u as o,b as u}from"./query-jNwYzAw-.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=r("Cpu",[["rect",{width:"16",height:"16",x:"4",y:"4",rx:"2",key:"14l7u7"}],["rect",{width:"6",height:"6",x:"9",y:"9",rx:"1",key:"5aljv4"}],["path",{d:"M15 2v2",key:"13l42r"}],["path",{d:"M15 20v2",key:"15mkzm"}],["path",{d:"M2 15h2",key:"1gxd5l"}],["path",{d:"M2 9h2",key:"1bbxkp"}],["path",{d:"M20 15h2",key:"19e6y8"}],["path",{d:"M20 9h2",key:"19tzq7"}],["path",{d:"M9 2v2",key:"165o2o"}],["path",{d:"M9 20v2",key:"i2bqo8"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=r("KeyRound",[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=r("Wifi",[["path",{d:"M12 20h.01",key:"zekei9"}],["path",{d:"M2 8.82a15 15 0 0 1 20 0",key:"dnpr2z"}],["path",{d:"M5 12.859a10 10 0 0 1 14 0",key:"1x1e6c"}],["path",{d:"M8.5 16.429a5 5 0 0 1 7 0",key:"1bycff"}]]);function k(a){return i({queryKey:["faqs",a],queryFn:async()=>(await s.get("/faqs",{params:a})).data})}function f(){const a=o();return u({mutationFn:async e=>(await s.post("/faqs",e)).data,onSuccess:()=>{a.invalidateQueries({queryKey:["faqs"]}),t.success("FAQ created")},onError:e=>{t.error(n(e,"Failed to create FAQ"))}})}function F(){const a=o();return u({mutationFn:async({id:e,...c})=>(await s.put(`/faqs/${e}`,c)).data,onSuccess:()=>{a.invalidateQueries({queryKey:["faqs"]}),t.success("FAQ updated")},onError:e=>{t.error(n(e,"Failed to update FAQ"))}})}function M(){const a=o();return u({mutationFn:async e=>{await s.delete(`/faqs/${e}`)},onSuccess:()=>{a.invalidateQueries({queryKey:["faqs"]}),t.success("FAQ deleted")},onError:e=>{t.error(n(e,"Failed to delete FAQ"))}})}export{h as C,l as K,q as W,f as a,F as b,M as c,k as u};
